var Wakeup = require('./wakeup');

module.exports = Wakeup;
