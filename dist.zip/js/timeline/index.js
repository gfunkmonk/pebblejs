var Timeline = require('./timeline');

Timeline.init();

module.exports = Timeline;
