var Platform = require('./platform');

module.exports = Platform;
